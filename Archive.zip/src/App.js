import React, { Component } from 'react';
import './App.css';
import Question from './Components/Question';
import jsonFile from './Questions.js';

class App extends Component {
  state= {
    allQuestions: [],
    question: '',
    answers: '',
    correct: ''
      
    
    
  }
  componentDidMount(){
   this.setState({allQuestions: jsonFile});
   
  
}

   
  render() {
    return (
      <div className="App">
      <h1></h1>
      <Question questions={this.state.question} answers={this.state.answers} correct={this.state.correct}  />
      <button onClick={this.getQuiz.bind(this)}>csaas</button>
      </div>
    );
  }
  getQuiz(){
    var counter = 0;
    var question = this.state.allQuestions[counter].question;
    var answers = this.state.allQuestions[counter].answers;
    var correct = this.state.allQuestions[0].correct;
    this.setState({question: question, answers:answers, correct:correct  });
  }
}

export default App;
