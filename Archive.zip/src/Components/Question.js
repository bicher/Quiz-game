import React, { Component } from 'react';


class Question extends Component {
    state = {
        gameStart: false,
        currectAnswer: '',
        answerChoice: '',
        counter: 0
    }
    render() {
        return (
            <div className="Question mt-5">
                <div className="container">
                    <div className="row">
                        <div className="col-lg-10 col-lg-offset-1 mx-auto">
                            <div className="text-center">
                                <h4>{this.props.questions}</h4>
                            </div>
                            <ul>
                                {/* {this.props.answer.map(a => (
                                    <li><span className="mx-auto d-flex align-items-center">{a}</span></li>
                                ))} */}


                                {/* {this.props.answer.map(a => (
                                    <li>{a}</li> 
                                    
                                ))} */}



                            </ul>
                            {/* <li><span className="mx-auto d-flex align-items-center">Tel Aviv</span></li>
                                <li><span className="mx-auto d-flex align-items-center">Jerusalem</span></li>
                                <li><span className="mx-auto d-flex align-items-center">Haifa</span></li>
                                <li><span className="mx-auto d-flex align-items-center">Eilat</span></li> */}

                            <button className="btn btn-secondary float-left" id="prev" onClick={this.prev.bind(this)}>Prev</button>
                            <button className="btn btn-secondary float-right" id="next" onClick={this.next.bind(this)}>Next</button>
                        </div>
                    </div>
                </div>
            </div>
        );
    }
    next() {
        if (this.state.counter < 1) {
            this.setState({ counter: this.state.counter + 1 });
            document.getElementById("prev").disabled = false;
            document.getElementById("next").innerHTML = "Done";
        }
    }

    prev() {
        document.getElementById("prev").disabled = true;
        if (this.state.counter > 0) {
            this.setState({ counter: this.state.counter - 1 });
            document.getElementById("next").innerHTML = "Next";

        }
    }
}

export default Question;
