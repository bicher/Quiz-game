export default  [
  {
    question: 'Which city is the capital of England?',
    answers: ['London', 'Mancester', 'Sheffield', 'Edinburgh'],
    correct: 'London'
  },
  
  {
    question: 'Where in an HTML document is the correct place to refer to an external style sheet?',
    answers: ['Tel Aviv', 'Jerusalem', 'Haifa', 'Eilat'],
    correct: 'Jerusalem'
  }

]

